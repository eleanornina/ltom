<?php get_header(); ?>

	<!-- BEGIN PAGE -->
	<div id="page">
    <div id="page-inner" class="clearfix">
		<div id="pagecontpro" class="woo">	
<div class="entry" class="clearfix">
		<?php woocommerce_content(); ?>
			      		</div>						
			      		</div>										
<?php get_footer(); ?>
