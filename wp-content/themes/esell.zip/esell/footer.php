</div></div>
<?php get_template_part('/includes/adfun'); ?>
<?php wp_footer(); ?>
<script src="//ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script type="text/javascript" src="http://www.eleanornina.com/littletouchofmagic/wp-content/themes/esell/inc/js/package.js"></script>
</body>
</html>