--------------------------------------------------------
Thanks for Downloading eSell theme
--------------------------------------------------------
I made this for free to use if you find any bug or error please
You can directly contact us: http://forum.insertcart.com
also suggestion are welcome

-------------------------------------------------------
************************Installation*******************
-------------------------------------------------------

Read Documentation : http://www.wrock.org/setup-esell-woocommerce-premium-theme-guide/

1.Upload theme to Dashboard > Appearance > Themes > Add new > upload theme
if fails then upload directly to server via FTP in website dir /wp-content/themes/
2.Activate theme from dashboard themes
3.For settings go to Dashboard > Appearance > eSell Options [for all theme related settings]
4.Upload Logo here, Set featured images and other pages

HOW TO SHOW WOOCOMMERCE PRODUCTS ON FRONT PAGE:
5. you need to set featured product to show on main page navigate to Dashboard > Products > and click on star mark to show products
6.Increase or decrease products from eSell option at home page


--------------------------eSell------------------------
Features:

Theme have many features like some main are listed below

Theme option:
-upload favicon from theme option by url
-Customize you site background color or image
-show 5 latest posts with thumbnail in right sidebar -activate from theme option > General settings
-enable search from theme option > General settings

Home Page:
-Customize your home page here
-put woocommerce products and featured post


Advertise:
-Add text link below navigation
-Ads supports single post and footer best for adsense

Social:
-Add you fan page or follow page of Facebook, twitter, Rss feed, Google+,Linkedin from theme option > Social Media

Custom Css:
-Also support for Custom Css with you have not need to change main style.css file


== Change log ==

= 1.2.6 =
* Fixed Table issue in post and pages
* Fixed calendar issue in widgets
* Updated comments.php codes
* Fixed other minor issue
* Language support for Italian added

= 1.2.5 =
* Fixed some minor issue
* Now Recent Woocommerce Products will show
* Edit some stylesheet css 

= 1.2.4 =
* Option Framework updated
* Fix missing text domain
* Some other minor updated 

= 1.2.3.3 =
*Fix issue for woocommerce theme support
*Fix main featured area height
*Fix other minor issues

= 1.2.3.2 =
*Fixed Long product name issue with woocommerce
*Fixed minor issues

= 1.2.3.1 =
*Fixed woocommerce product issue on some pages

= 1.2.3 =
*Option Framework updated
*Now you can upload favicon
*Sidebar Added into Pages
*Woocommercce Support fixed

= 1.2.2 =
*Fixed some issue
*Demo text added
*wp_nav_menu issue fixed 

= 1.0 =
*Initial Release @ 1.0

== License ==

*Option Framework : Author is "Devin Price" provided at http://www.wptheming.com under License GPLv2 (All file Included in "inc" folder)
*Social Icons: are provided by "Konstantin Kovshenin" URL: http://kovshenin.com/2011/freebies-a-simple-social-icon-set-gpl/ Which in under GPL v2
*Images into /images/ folder that's are created by me abno.png, cat.png home.jpg, info.png, logo.png metaimg.png, quote.png, thumb.png are publish Under gpl v2
*Fonts Monda: Copyright (c) 2012, vernon adams (vern@newtypography.co.uk)  This Font Software is licensed under the SIL Open Font License, Version 1.1. http://scripts.sil.org/OFL

**This theme and file are created by me & publish under GPLv3